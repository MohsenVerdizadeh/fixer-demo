from setuptools import setup

setup(
    name='fixer_demo',
    version='0.1',
    description="Fixer Service demo packages",
    url="#",
    author="mohsen",
    author_email='mohsenverdizadehkohi@gmail.com',
    license='MIT',
    packages=['fixer'],
    zip_safe=False
)
