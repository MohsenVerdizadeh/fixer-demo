def get_rates():
    print('Get rates touched.')